# Meghana Kambhampati
# MXK190048
# CS 4395.001
# Portfolio 5: Finding or Building a Corpus
# This program builds a web crawler. It uses a starter url
# and "crawls" along a web of links to gather information.
# The information is scraped and the most important terms
# are taken from it. This is used to create a simple
# knowledge base.

import math
from nltk import punkt
from urllib.request import Request, urlopen
import re
from bs4 import BeautifulSoup, element
import requests
import pickle
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from urllib import request
import pprint

'''
Gets 15 links related to the main topic, chocolate using requests
and BeautifulSoup. 

Returns: a list of 15 relevant links.
'''


def get_links():
    starter_url = "https://en.wikipedia.org/wiki/Chocolate"

    r = requests.get(starter_url)

    data = r.text
    soup = BeautifulSoup(data, "html.parser")
    url_list = []

    counter = 0
    for link in soup.find_all('a'):
        link_str = str(link.get('href'))
        if "Chocolate" in link_str or "chocolate" in link_str:
            if link_str.startswith("/url?q="):
                link_str = link_str[7:]
                print(link_str)
            if "&" in link_str:
                i = link_str.find("&")
                link_str = link_str[:i]
            if link_str.startswith("http") and "google" not in link_str and "wiki" not in link_str:
                print(link_str + '\n')
                url_list.append(link_str)
                counter += 1
            if counter > 14:
                break
    return url_list


'''
Cleans up raw text from urls and tokenizes resulting sentences.
Used in the scrape_text function.
'''


def clean_and_tokenize_text():
    for i in range(1, 15):
        with open('url' + str(i) + '_raw.txt', 'r') as f:
            raw_text = f.read()
            if '\n' in raw_text:
                raw_text = raw_text.replace('\n', '')
            if '\t' in raw_text:
                raw_text = raw_text.replace('\t', '')
            raw_text = str(raw_text)
            raw_text = re.sub('\s+', ' ', raw_text)
            sents = sent_tokenize(raw_text)
            sent_file = open('url' + str(i) + '.txt', 'w')
            sent_file.write('\n'.join(sents))
            sent_file.close()


'''
Scrapes raw text from each url in list and puts contents in 
separate files

Args: list of urls
'''


def scrape_text(url_list):
    counter = 1
    for url in url_list:
        r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})

        def tag_visible(tag):
            if tag.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
                return False
            if isinstance(tag, element.Comment):
                return False
            return True
        soup = BeautifulSoup(r.content.decode('utf-8'), 'html.parser')
        texts = soup.findAll(string=True)
        visible_texts = filter(tag_visible, texts)  
        temp_str = " ".join(t.strip() for t in visible_texts)

        raw_text_file = open('url' + str(counter) + '_raw.txt', 'w')
        raw_text_file.write("".join(temp_str))
        raw_text_file.close()
        counter += 1

    clean_and_tokenize_text()


'''
Calculates tf or term frequency of tokens in a piece of text.
Called by the extract_important_terms function.

Args: The text that contains the tokens being counted

Returns: a dictionary of term frequencies for each token
'''


def calculate_tf(text):
    stop_words = set(stopwords.words('english'))
    tokens = word_tokenize(text)
    tokens = [w for w in tokens if w.isalpha()
              and w not in stop_words
              and len(w) > 3]

    # get term frequencies
    token_set = set(tokens)
    tf_dict = {t: tokens.count(t) for t in token_set}

    # normalize tf
    for t in tf_dict.keys():
        tf_dict[t] = tf_dict[t] / len(tokens)

    return tf_dict


'''
Calculates the idf or inverse document frequency of a given
token in all documents. Called by the extract_important_terms
function.

Args: list of dictionaries of terms for all files

Returns: a dictionary of the idf for each term
'''


def calculate_idf(dict_list, vocab):
    vocab_by_term = []
    idf_dict = {}
    for tf_dict in dict_list:
        vocab_by_term.append(tf_dict.keys())

    for term in vocab:
        temp = ['x' for voc in vocab_by_term if term in voc]
        idf_dict[term] = math.log((1 + 15) / (1 + len(temp)))

    return idf_dict


'''
Calculates td-idf. Used in extract_important_terms.

Args: dictionary of tf values for each term
      dictionary of idf values

Returns: Dictionary of td-idf values for each term
'''


def calculate_td_idf(tf, idf):
    tf_idf = {}
    for t in tf.keys():
        tf_idf[t] = tf[t] * idf[t]

    return tf_idf


'''
Extracts 40 important words from the text. The 10 most important 
words out of these will be chosen manually.

Args: List of urls

Returns the top 40 most important terms
'''


def extract_important_terms(url_list):
    scrape_text(url_list)
    tf_dict_list = list(dict())

    for i in range(1, 15):
        with open('url' + str(i) + '_raw.txt', 'r') as f:
            # create a list of dictionaries where each dict
            # corresponds to a file and each dict holds tf
            # values for a given file
            contents = str(f.read()).lower()
            contents = re.sub('\s+', ' ', contents)
            tf_dict_list.append(calculate_tf(contents))

    # add keys of each dict in dict_list to vocab
    vocab = set(tf_dict_list[0].keys())
    for i in range(1, 14):
        vocab = vocab.union(set(tf_dict_list[i].keys()))

    idf = calculate_idf(tf_dict_list, vocab)

    # td-idf calculations
    tf_idfs = dict()
    for i in range(0, 14):
        for (word, weight) in calculate_td_idf(tf_dict_list[i], idf).items():
            if word in tf_idfs:
                tf_idfs[word] += weight
            else:
                tf_idfs[word] = weight
    term_weights_list = sorted(tf_idfs.items(), key=lambda x: x[1], reverse=True)

    for i in range(25):
        print(term_weights_list[i][0] + ' (' + str(term_weights_list[i][1]) + ' times)')


'''
Defines the top 10 most important terms and creates a 
knowledge base with it. 

Args:

Returns: A dictionary with information on each term
'''


def create_knowledge_base():
    top_10_terms = ['maya', 'chocolate', 'cacao', 'field', 'seeds', 'aztecs', 'food', 'drank', 'process', 'ancient']
    choc_knowledge_base = dict()
    for i in range(1, 15):
        with open('url' + str(i) + '.txt', 'r') as f:
            sents = f.read()
            for sent in sents.split('\n'):
                for item in top_10_terms:
                    if item in sent:
                        if item in choc_knowledge_base:
                            choc_knowledge_base[item].append('\n' + sent)
                        else:
                            choc_knowledge_base[item] = [sent]
    pickle.dump(choc_knowledge_base, open('choc_knowledge_base.p', 'wb'))


def main():
    url_list = get_links()
    extract_important_terms(url_list)
    create_knowledge_base()


if __name__ == '__main__':
    main()
