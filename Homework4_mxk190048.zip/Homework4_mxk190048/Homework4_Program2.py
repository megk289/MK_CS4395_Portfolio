# Meghana Kambhampati
# MXK190048
# CS 4395.001
# Portfolio 4: N-grams Program 2
# This program creates unigram and bigram dictionaries
# for English, French, and Italian using a training corpus.
# Given test data, the program calculates the probability of
# it being in English, French, and Italian. It then chooses
# the language with the highest probability and outputs it to a file.
# It also outputs the accuracy of language detection and the line
# numbers of misidentified items.

import pickle
from nltk import *
import codecs


'''
Calculates the probability of a language for each line of a given a piece of text

Args: the unigram dictionary with the unigrams as keys 
        and counts as values
      the bigram dictionary with the bigrams as keys 
        and counts as values
      the size of the vocabulary (the lengths of the unigram
        dictionaries

Returns: the probability of the language for each line
'''


def compute_probability(filename, unigram_dict, bigram_dict, vocab_size):
    with open(filename, "r") as f:
        text = f.readlines()

    # Laplace
    probs = []
    for line in text:
        p_laplace = 1
        unigrams_test = word_tokenize(line)
        bigrams_test = list(ngrams(unigrams_test, 2))
        for bigram in bigrams_test:
            b = bigram_dict.get(bigram, 0)
            u = unigram_dict.get((bigram[0],), 0)
            p_laplace = p_laplace * ((b + 1) / (u + vocab_size))
        probs.append(p_laplace)

    return probs


'''
Check the accuracy of the language model predictions and output
them.
'''


def check_accuracy():
    solutions = []
    output = []
    with codecs.open('LangId.sol', "r", "utf-8") as f:
        sol_text = f.readlines()

    for line in sol_text:
        _line_num, lang = line.split(' ')
        solutions.append(lang.strip())

    with codecs.open('output.txt', "r", "utf-8") as f:
        out_text = f.readlines()

    for line in out_text:
        _line_num, lang = line.split(' ')
        output.append(lang.strip())

    incorrect = 0
    total = 0
    for line_num in range(len(output)):
        if solutions[line_num] != output[line_num]:
            print(str(line_num) + ' Solution: ' + solutions[line_num] + ', Predicted: ' + output[line_num])
            incorrect += 1

        total += 1

    # print calculated accuracy
    print('\n' + "{0:.0%} inaccurate".format(incorrect / total))


def main():
    # load pickled dictionaries
    english_uni = pickle.load(open('english_uni.p', 'rb'))
    english_bi = pickle.load(open('english_bi.p', 'rb'))

    french_uni = pickle.load(open('french_uni.p', 'rb'))
    french_bi = pickle.load(open('french_bi.p', 'rb'))

    italian_uni = pickle.load(open('italian_uni.p', 'rb'))
    italian_bi = pickle.load(open('italian_bi.p', 'rb'))

    # calculate probabilities for each language
    vocab_size = len(english_uni) + len(french_uni) + len(italian_uni)
    eng = compute_probability('LangId.test', english_uni, english_bi, vocab_size)
    fr = compute_probability('LangId.test', french_uni, french_bi, vocab_size)
    it = compute_probability('LangId.test', italian_uni, italian_bi, vocab_size)

    # write the highest probability language of each line to a file
    out_file = open("output.txt", "w")

    # find most likely language for each line
    for line in range(0, len(eng)):
        max_prob = max(eng[line], fr[line], it[line])
        if max_prob == eng[line]:
            out_file.write( str(line + 1) + ' English\n')
        elif max_prob == fr[line]:
            out_file.write(str(line + 1) + ' French\n')
        elif max_prob == it[line]:
            out_file.write(str(line + 1) + ' Italian\n')
        else:
            out_file.write(str(line + 1) + ' Error\n')

    # close output file
    out_file.flush()
    out_file.close()

    check_accuracy()


if __name__ == '__main__':
    main()
