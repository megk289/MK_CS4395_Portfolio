# Meghana Kambhampati
# MXK190048
# CS 4395.001
# Portfolio 4: N-grams Program 1

# This program creates unigram and bigram dictionaries
# for English, French, and Italian using a training corpus.
# Given test data, the program calculates the probability of
# it being in English, French, and Italian. It then chooses
# the language with the highest probability and outputs it to a file.
# It also outputs the accuracy of language detection and the line
# numbers of misidentified items.


import codecs
import pickle
from nltk import *


'''
Opens the training file and 

Args: name of the training file

Returns: unigram and bigram dictionaries where the unigram 
    or bigram is the key and its count is the value.
'''


def create_language_models(filename):
    with codecs.open(filename, "r", "utf-8") as f:
        raw_text = re.sub('\n', ' ', f.read())

    tokens = word_tokenize(raw_text)

    unigrams = list(ngrams(tokens, 1))
    bigrams = list(ngrams(tokens, 2))

    unigram_dict = {t: unigrams.count(t) for t in set(unigrams)}
    bigram_dict = {b: bigrams.count(b) for b in set(bigrams)}

    return unigram_dict, bigram_dict


def main():
    # download nltk components
    download('punkt')

    # create and pickle dictionaries
    english_uni, english_bi = create_language_models('LangId.train.English')
    pickle.dump(english_uni, open('english_uni.p', 'wb'))
    pickle.dump(english_bi, open('english_bi.p', 'wb'))

    french_uni, french_bi = create_language_models('LangId.train.French')
    pickle.dump(french_uni, open('french_uni.p', 'wb'))
    pickle.dump(french_bi, open('french_bi.p', 'wb'))

    italian_uni, italian_bi = create_language_models('LangId.train.Italian')
    pickle.dump(italian_uni, open('italian_uni.p', 'wb'))
    pickle.dump(italian_bi, open('italian_bi.p', 'wb'))


if __name__ == '__main__':
    main()
